package catalogue;

import java.io.Serializable;
import java.util.Collections;

/**
 * Write a description of class BetterBasket here.
 * 
 * @author  Your Name 
 * @version 1.0
 */
public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;
  private int theOrderNum = 0; // the OrderNum for products purchased
  private int productQuantity; // the default quantity for the products

/**
 * Constructor that extends to the BetterBasket which is
 * used to represent a customer order/wish list
 */
  public BetterBasket()
  {
	  theOrderNum = 0; // The order number for products
  }
  
  public int theProductNum()
  {
	  setProductQuantity(getProductQuantity() + 1);
	  return productQuantity;
	  }
	
  

public int getProductQuantity() {
	return productQuantity;
}

public void setProductQuantity(int productQuantity) {
	this.productQuantity = productQuantity;
}
}
