package javax.persistence;

public @interface GeneratedValue {
	String SEQUENCE = null;

	String strategy();
} 

	


	
