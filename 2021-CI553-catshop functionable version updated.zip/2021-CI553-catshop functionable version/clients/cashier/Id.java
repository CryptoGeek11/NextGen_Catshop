package clients.cashier;

public @interface Id {

}
