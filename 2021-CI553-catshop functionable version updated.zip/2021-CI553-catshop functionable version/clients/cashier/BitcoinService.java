import java.util.logging.Logger;

@Service
public class BitcoinService {

	private static java.lang.System.Logger LOGGER = LoggerFactory.getLogger(BitcoinService.class);

	@Autowired
	private BitcoinJSONRPCClient bitcoinJSONRPCClient;


	public void bitcoinListener(String data) {
		String transactionHash = data.replace("txid=", "");
		Logger.info("transactionHash is : {}", transactionHash);
			TransactionDTO transactionDTO = getReceivedTransactionInfo(transactionHash);
		}

	

	public <TransactionDTO> TransactionDTO getReceivedTransactionInfo(String transactionHash) {
		TransactionDTO transactionDTO = null;
		try {
			Object object = bitcoinJSONRPCClient.query("gettransaction", transactionHash);
			ObjectMapper mapper = new ObjectMapper();
			transactionDTO = mapper.convertValue(object, TransactionDTO.class);
			logger.info("transaction Data successfully received from blockchain");
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
		return transactionDTO;
	}
}
