package clients.cashier;

public @interface RestController {

}
