package clients.cashier;

public @interface RequestBody {

}
