package clients.cashier;

public @interface VariableDeclaratorId {

}
