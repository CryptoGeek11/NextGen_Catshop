package clients.cashier;

public @interface GeneratedValue {

	String strategy();

}
