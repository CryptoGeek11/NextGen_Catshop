package clients.cashier;

public class DetailsDTO {
        private String account;
        private String address;
        private String category;
        private Double amount;
        
        public String getAccount() {
        	return account;
        }
        
        public void setAccount(String account) {
        	this.account = account;
        }
        
        public String getAddress() {
        	return address;
        }
        
        public void setAddress(String address) {
        	this.address = address;
        }
        
        public String getCategory() {
        	return category;
        }
        
        public void setCategory(String category) {
        	this.category = category;
        }
        
        public Double getAmount() {
        	return amount;
        }
        
        public void setAmount(Double amount) {
        	this.amount = amount;
        }
   } 
