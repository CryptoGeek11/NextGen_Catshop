package clients.cashier;

public @interface Entity {

}
