package clients.cashier;

public class RequestMapping {
	@VariableDeclaratorId
	 String method=RequestMethod.POST;
}