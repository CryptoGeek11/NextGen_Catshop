package clients.cashier;

public class GenerationType {

	public static final String AUTO = null;
	public static final String IDENTITY = null;

}
