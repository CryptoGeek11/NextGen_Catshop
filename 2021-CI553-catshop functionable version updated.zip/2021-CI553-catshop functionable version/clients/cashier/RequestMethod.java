package clients.cashier;

public class RequestMethod {

	public static final String POST = null;

}
