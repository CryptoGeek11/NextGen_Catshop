package clients.cashier;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.GeneratedValue;

import org.apache.derby.iapi.store.raw.Transaction;

import clients.cashier.BitcoinTransaction;

/**
 * @author Ryan Fagan
 * 
 * @Date 28-Aug-2022
 */
public class BitcoinTransaction {

	public BitcoinTransaction(Long userId, String transactionHash, String receiveToAddress, BigDecimal amount,
			TransactionType transactionType, Transaction transactionStatus, Date transactionDate) {
		super();
		this.userId = userId;
		this.transactionHash = transactionHash;
		this.amount = amount;
		this.transactionType = transactionType;
		this.transactionStatus = transactionStatus;
		this.transactionDate = transactionDate;
		
	}

 @Id
 @GeneratedValue(strategy = "GenerationType.AUTO")
 private Long id;
 
 private Long userId;
 
 private String sendToAddress;
 
 private String sendFromAddress; 
 
 private String transactionHash;
 
 private String receivedFromAddress;
 
 private BigDecimal amount;
 
 private TransactionType transactionType;
 
 private Transaction transactionStatus;
 
 private Date transactionDate = new Date();
 
 private Double transactionFee;
 
 public BitcoinTransaction() {
	 super();
 }
 
 public BitcoinTransaction(Long userId, BigDecimal amount, String sendToAddress, TransactionStatus transactionStatus,
		 String sendFromAddress, TransactionType transactionType) {
	 // TODO Auto-generated constructor stub
	 this.userId = userId;
	 this.amount = amount;
	 this.sendToAddress = sendToAddress;
	 this.transactionStatus = transactionStatus;
	 this.setSendFromAddress(sendFromAddress);
	 this.transactionType = transactionType;
}
 
 public BitcoinTransaction(Long userId, String receivedFromAddress, String receivedToAddress, BigDecimal
		 amount,
		       TransactionType transactionType, TransactionStatus transactionStatus) {
	 super();
	 this.userId = userId;
	 this.receivedFromAddress = receivedFromAddress;
	 this.amount = amount;
	 this.transactionType = transactionType;
	 this.transactionStatus = transactionStatus;
 }
 
 public String getReceivedFromAddress() {
	 return receivedFromAddress;
 }
 
 public void setReceivedToAddress(String receivedToAddress) {
 }
 
 public Long getId() {
	 return id;
 }
 
 public void setId(Long id) {
	 this.id = id;
 }
 
 public String getSendToAddress() {
	 return sendToAddress;
 }
 
 public void setSendToAddress(String sendToAddress) {
	 this.sendToAddress = sendToAddress;
 }
 
 public String getTransactionHash() {
	 return transactionHash;
 }
 
 public void setTransactionHash(String transactionHash) {
	 this.transactionHash = transactionHash;
 }
 
 public BigDecimal getAmount() {
	 return amount;
 }
 
 public void setAmount(BigDecimal amount) {
	 this.amount = amount;
 }
 
 public TransactionType getTransactionType() {
	 return transactionType;
 }
 
 public void setTransactionType(TransactionType transactionType) {
	 this.transactionType = transactionType;
 }
 
 public TransactionStatus getTransactionStatus() {
	 return (TransactionStatus) transactionStatus;
 }
 
 public void setTransactionStatus(TransactionStatus transactionStatus) {
	 this.transactionStatus = (Transaction) transactionStatus;
   }
 
 public Date getTransactionDate() {
	 return transactionDate;
 }

 public void setTransactionDate(Date transactionDate ) {
	 this.transactionDate = transactionDate;
 }
 
 public Double getTransactionFee() {
	 return transactionFee;
 }
 
 public void setTransactionFee(Double transactionFee) {
	 this.transactionFee = transactionFee;
 }
 
 public Long getUserId() {
	 return userId;
 }
 
 public void setUserId(Long userId) {
	 this.userId = userId;
 }

public String getSendFromAddress() {
	return sendFromAddress;
}

public void setSendFromAddress(String sendFromAddress) {
	this.sendFromAddress = sendFromAddress;
}
}
 