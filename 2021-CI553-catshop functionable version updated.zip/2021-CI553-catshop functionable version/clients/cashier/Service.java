package clients.cashier;

public @interface Service {

}
