package clients.cashier;

public @interface Autowired {

}
