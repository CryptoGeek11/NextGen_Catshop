package clients.cashier;

public interface URLMapping {

	String SAVE_BITCOIN_RECEIVE_TRANSACTION = null;

}
