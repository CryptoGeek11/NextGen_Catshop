package clients.cashier;

public TransactionDTO getReceivedTransactionInfo(String transactionHash) {
	TransactionDTO transactionDTO = null;
	try {
		Object object = bitcoinJSONRPCClient.query("gettransaction", transactionHash);
		ObjectMapper mapper = new ObjectMapper();
		transactionDTO = mapper.convertValue(object, TransactionDTO.class);
		logger.info("transaction Data successfully received from blockchain");
	} catch (Exception ex) {
		logger.error(ex.getMessage());
	}
	return transactionDTO;
}
}