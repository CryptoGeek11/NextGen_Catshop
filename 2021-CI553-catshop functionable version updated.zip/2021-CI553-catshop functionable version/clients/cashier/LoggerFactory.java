package clients.cashier;

import java.io.Serializable;
import java.util.logging.Logger;

public class LoggerFactory {

	public static java.lang.System.Logger getLogger(Serializable class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
