package clients.cashier;

import java.util.Properties;

import org.apache.derby.iapi.error.StandardException;
import org.apache.derby.iapi.services.context.ContextManager;
import org.apache.derby.iapi.services.daemon.Serviceable;
import org.apache.derby.iapi.services.locks.CompatibilitySpace;
import org.apache.derby.iapi.services.property.PersistentSet;
import org.apache.derby.iapi.store.access.FileResource;
import org.apache.derby.iapi.store.access.RowSource;
import org.apache.derby.iapi.store.raw.ContainerHandle;
import org.apache.derby.iapi.store.raw.ContainerKey;
import org.apache.derby.iapi.store.raw.GlobalTransactionId;
import org.apache.derby.iapi.store.raw.LockingPolicy;
import org.apache.derby.iapi.store.raw.Loggable;
import org.apache.derby.iapi.store.raw.StreamContainerHandle;
import org.apache.derby.iapi.store.raw.Transaction;
import org.apache.derby.iapi.store.raw.log.LogInstant;
import org.apache.derby.iapi.types.DataValueFactory;

public class TransactionType implements Transaction {

	@Override
	public void abort() throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long addAndLoadStreamContainer(long arg0, Properties arg1, RowSource arg2) throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long addContainer(long arg0, long arg1, int arg2, Properties arg3, int arg4) throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void addPostAbortWork(Serviceable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addPostCommitWork(Serviceable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addPostTerminationWork(Serviceable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean anyoneBlocked() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close() throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public LogInstant commit() throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LogInstant commitNoSync(int arg0) throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createXATransactionFromLocalTransaction(int arg0, byte[] arg1, byte[] arg2) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroy() throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dropContainer(ContainerKey arg0) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dropStreamContainer(long arg0, long arg1) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getActiveStateTxIdString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompatibilitySpace getCompatibilitySpace() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ContextManager getContextManager() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DataValueFactory getDataValueFactory() throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LockingPolicy getDefaultLockingPolicy() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FileResource getFileHandler() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GlobalTransactionId getGlobalId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isIdle() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isPristine() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void logAndDo(Loggable arg0) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public LockingPolicy newLockingPolicy(int arg0, int arg1, boolean arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ContainerHandle openContainer(ContainerKey arg0, int arg1) throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ContainerHandle openContainer(ContainerKey arg0, LockingPolicy arg1, int arg2) throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StreamContainerHandle openStreamContainer(long arg0, long arg1, boolean arg2) throws StandardException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int releaseSavePoint(String arg0, Object arg1) throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int rollbackToSavePoint(String arg0, Object arg1) throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setDefaultLockingPolicy(LockingPolicy arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setNoLockWait(boolean arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int setSavePoint(String arg0, Object arg1) throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setup(PersistentSet arg0) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void xa_commit(boolean arg0) throws StandardException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int xa_prepare() throws StandardException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void xa_rollback() throws StandardException {
		// TODO Auto-generated method stub
		
	}

}
