package clients.cashier;

public @interface Temporal {

	String TIMESTAMP = null;

	String value();

}
