package catalogue;

import java.io.Serializable;
import java.util.Collections;

/**
 * Write a description of class BetterBasket here.
 * 
 * @author  Ryan Fagan
 * @version 2.0
 */
public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;
  
  private int theQuantity = 1; // Each time a purchase of the same product in made.
  private int theOrderNum = 0; // Default theOrderNum so the user can react with the product number
  
  /**
   * Constructor for the BetterBasket which is
   * used to represent a customer order/ wish list
   * with the @para product to be associated as repeated products
 * @return 
   */
   public BetterBasket()
   {
	   theQuantity = 1; // Variable for associated repeated product numbers / wish lists
	   theOrderNum = 0; // Order numbers for products
   }
   
   /** 
    * Set the customers unique order number
    * with a condition if theOrderNum is more than product
    */
   public void setOrderNum( int anOrderNum, int anQuantity)
   {
	   System.out.println("Enter the product number"); // Asks the user to enter the product number of the item you wish to purchase
		  theOrderNum = anOrderNum;
		  theQuantity = anQuantity;
	   }
   }


